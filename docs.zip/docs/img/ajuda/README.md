# Llista d'imatges de la documentació
* *01-Pantallazo-Pantalla Login - Chromium.png*	
* 02-Pantallazo-Autenticacion Profesor - Chromium.png	
* 03-Pantallazo-Autenticacion Alumno - Chromium.png	
* 04-oculto-Pantallazo-Panel de control - Chromium.png	
* *04-Pantallazo-Panel de control - Chromium.png*
* *05-btnNotificacions.png*
* 05-Mensajes-Pantallazo-Panel de control - Chromium.png	
* 05-Pantallazo-Panel de control - Chromium.png	
* 05-Pantallazo-Panel de control - Chromium.xcf	
* 06-divNotificacions.png	
* 06-reloj-Pantallazo-Panel de control - Chromium.png	
* *07-miDep.png*	
* 07-perfil-Pantallazo-Panel de control - Chromium.png	
* *08-perfil-Pantallazo-Modificar Perfil Profesor - Chromium.png*
* *09-grupos.png*
* *09-programacions.png*	
* 10-Pantallazo-Buscar Documentos - Chromium.png	
* *10-seguiments.png*	
* *12-actExtr-alta.png*
* *12-actExtr-detalle.png*
* *12-actExtr-listado.png*
* *12-actExtr-mosaico.png*
* *13-ausencia.png*
* *13-comisions.png*
* *13-comissions-alta.png*
* *14-ausencia-alta.png*
* *14-guardia.png*
* 14-guardias.png	
* 15-enlaces-Pantallazo-Panel de control - Chromium.png	
* *15-reunio.png*	
* 20-dep-Pantallazo-Listado Profesores - Chromium.png	
* 20-perfil.png	
* 21-dep-lista-Pantallazo-Listado Profesores - Chromium.png	
* 22-grupos-Pantallazo-Grupos - Chromium.png	
* *30-taula.png*	
* 30-taula.xcf	
* centros.png	
* colaboraciones.png	
* espacios.png	
* fcts.png
